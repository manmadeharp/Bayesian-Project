Written by Finbar Cowan from 2 semester research project on Bayesian Inverse Problems with a focus on MCMC methods for sampling approximately/directly/exactly from the Posterior distribution.

Work in Progress.

For most up to date and interesting part of the project, please run ReactionDiffusion.py